Awesome tool for https://hoadondientu.gdt.gov.vn/
![image](https://github.com/TechMarDay/HoaDonDienTuTool/assets/71170503/a9a64d42-8a26-4a44-82fb-b211dcd26d52)
